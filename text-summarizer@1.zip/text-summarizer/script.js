document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("inputType").addEventListener("change", toggleInputFields);
});

function toggleInputFields() {
    let inputType = document.getElementById("inputType").value;
    document.getElementById("textInput").style.display = (inputType === "text") ? "block" : "none";
    document.getElementById("pdfInput").style.display = (inputType === "pdf") ? "block" : "none";
    document.getElementById("urlInput").style.display = (inputType === "url") ? "block" : "none";
}

function summarizeText() {
    let inputType = document.getElementById("inputType").value;
    let formData = new FormData();

    if (inputType === "text") {
        let text = document.getElementById("inputText").value.trim();
        if (!text) {
            alert("Please enter some text.");
            return;
        }
        formData.append("text", text);
    } else if (inputType === "pdf") {
        let file = document.getElementById("pdfFile").files[0];
        if (!file) {
            alert("Please select a PDF file.");
            return;
        }
        formData.append("file", file);
    } else if (inputType === "url") {
        let url = document.getElementById("inputURL").value.trim();
        if (!url) {
            alert("Please enter a valid URL.");
            return;
        }
        formData.append("url", url);
    }

    fetch("/summarize_text", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.summary) {
            document.getElementById("summary").innerText = data.summary;
        } else {
            alert("Error: " + data.error);
        }
    })
    .catch(error => console.error("Error:", error));
}
