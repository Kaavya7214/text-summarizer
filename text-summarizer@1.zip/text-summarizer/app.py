import os

import fitz  # PyMuPDF for PDFs
import requests
from bs4 import BeautifulSoup
from flask import Flask, jsonify, request, send_from_directory
from transformers import BartForConditionalGeneration, BartTokenizer

app = Flask(__name__, static_folder=".", static_url_path="")

# Load BART tokenizer and model
tokenizer = BartTokenizer.from_pretrained("facebook/bart-large-cnn")
model = BartForConditionalGeneration.from_pretrained("facebook/bart-large-cnn")

# Function to generate summary
def generate_summary(text):
    if not text.strip():
        return "No meaningful content to summarize."

    inputs = tokenizer(text, return_tensors="pt", max_length=1024, truncation=True)
    summary_ids = model.generate(inputs["input_ids"], max_length=150, min_length=40, length_penalty=2.0, num_beams=4, early_stopping=True)
    return tokenizer.decode(summary_ids[0], skip_special_tokens=True)

# Extract text from PDF
def extract_text_from_pdf(pdf_path):
    try:
        doc = fitz.open(pdf_path)
        text = "\n".join(page.get_text() for page in doc if page.get_text())
        return text if text.strip() else "No readable text found in PDF."
    except Exception as e:
        return f"Error processing PDF: {str(e)}"

# Extract text from URL
def extract_text_from_url(url):
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        paragraphs = [p.get_text() for p in soup.find_all("p")]
        return " ".join(paragraphs) if paragraphs else "No readable text found on the webpage."
    except requests.exceptions.RequestException as e:
        return f"Error fetching URL: {str(e)}"

# Serve HTML pages
@app.route("/")
def about():
    return send_from_directory(".", "about.html")

@app.route("/summarize")
def summarize():
    return send_from_directory(".", "summarize.html")

# Serve static files (CSS and JS)
@app.route("/styles.css")
def styles():
    return send_from_directory(".", "styles.css")

@app.route("/script.js")
def script():
    return send_from_directory(".", "script.js")

# Summarization API
@app.route("/summarize_text", methods=["POST"])
def summarize_text():
    try:
        if "text" in request.form:
            text = request.form["text"].strip()
            if not text:
                return jsonify({"error": "No text provided"}), 400
            summary = generate_summary(text)

        elif "file" in request.files:
            file = request.files["file"]
            if not file:
                return jsonify({"error": "No file uploaded"}), 400

            pdf_path = f"temp_{file.filename}"
            file.save(pdf_path)  # Save file temporarily
            extracted_text = extract_text_from_pdf(pdf_path)
            os.remove(pdf_path)  # Remove temp file
            summary = generate_summary(extracted_text)

        elif "url" in request.form:
            url = request.form["url"].strip()
            if not url:
                return jsonify({"error": "No URL provided"}), 400
            extracted_text = extract_text_from_url(url)
            summary = generate_summary(extracted_text)

        else:
            return jsonify({"error": "Invalid input"}), 400

        return jsonify({"summary": summary})

    except Exception as e:
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500

if __name__ == "__main__":
    app.run(debug=True)
